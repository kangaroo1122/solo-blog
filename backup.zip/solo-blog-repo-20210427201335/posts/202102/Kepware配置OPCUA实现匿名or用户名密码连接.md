title: Kepware配置OPC UA实现匿名or用户名/密码连接
date: '2021-02-21 13:27:31'
updated: '2021-02-21 14:11:24'
tags: [kepware, OPCUA]
permalink: /articles/2021/02/21/1613885251501.html
---
![](https://b3logfile.com/bing/20201026.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

kepware提供了OPC UA的配置功能，稍微配置一下，即可启用OPC UA，在Java可以借助eclipse的milo项目，实现对kepware的读写，控制下位PLC。

## 1 环境

- Windows 7/10
- KEPServerEX 6.6

## 2 配置

### 2.1 防火墙

UPC UA默认使用49320端口，Windows上要么出站规则放行49320端口，要么直接关掉防火墙，这里在虚拟机测试，直接关闭系统防火墙即可。

### 2.2 匿名模式

首先启用OPC UA功能，kepware面板上**项目**右键，属性面板打开，切换到**OPC UA**选项，启用OPC UA。

![image.png](https://b3logfile.com/file/2021/02/image-baf6a34f.png)

打开**KEPServerEX 6 Administration**，选择**OPC UA配置**选项，进行相应配置。

![image.png](https://b3logfile.com/file/2021/02/image-1ec4e2d9.png)

配置完成后，重启kepware运行时即可生效

![image.png](https://b3logfile.com/file/2021/02/image-b4757a41.png)

### 2.3 测试匿名连接

使用OPC UA测试工具进行连接，这里使用的是开源项目[OpcUaHelper](https://github.com/dathlin/OpcUaHelper)，自己用VS 2017打包了一下，直接测试。

![image.png](https://b3logfile.com/file/2021/02/image-ea41e48a.png)

### 2.4 用户名/密码模式

首先需要配置 用户名/密码，打开**KEPServerEX 6 Administration**，选择**设置**选项，进行相应配置。

![image.png](https://b3logfile.com/file/2021/02/image-b5f48455.png)

![image.png](https://b3logfile.com/file/2021/02/image-ea31aaaa.png)

![image.png](https://b3logfile.com/file/2021/02/image-a7c5ca47.png)

### 2.5 测试用户名/密码连接

将2.2中的允许匿名登录关闭，重新初始化kepware，再次使用OpcUaHelper进行连接测试。

![image.png](https://b3logfile.com/file/2021/02/image-3cb3606d.png)
