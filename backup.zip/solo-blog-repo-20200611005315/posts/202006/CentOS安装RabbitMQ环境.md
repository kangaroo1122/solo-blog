title: CentOS安装RabbitMQ环境
date: '2020-06-07 23:55:09'
updated: '2020-06-07 23:56:47'
tags: [RabbitMQ, rpm, CentOS]
permalink: /articles/2020/06/07/1591545309473.html
---
![](https://b3logfile.com/bing/20190715.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 1 Erlang安装 (22.3.4.1版本)

## 1.1 在线安装

这里选用的Erlang是rabbitMQ官方提供的精简包，只有rabbitMQ运行所必须的环境

### 1.1.1 配置软件仓库和签名密钥

```
vi /etc/yum.repos.d/rabbitmq-erlang.repo
```

To use Erlang 22.x on CentOS 7：

```
[rabbitmq-erlang]
name=rabbitmq-erlang
baseurl=https://dl.bintray.com/rabbitmq-erlang/rpm/erlang/22/el/7
gpgcheck=1
gpgkey=https://dl.bintray.com/rabbitmq/Keys/rabbitmq-release-signing-key.asc
repo_gpgcheck=0
enabled=1
```

To use Erlang 22.x on CentOS 8:

```
[rabbitmq-erlang]
name=rabbitmq-erlang
baseurl=https://dl.bintray.com/rabbitmq-erlang/rpm/erlang/22/el/8
gpgcheck=1
gpgkey=https://dl.bintray.com/rabbitmq/Keys/rabbitmq-release-signing-key.asc
repo_gpgcheck=0
enabled=1
```

### 1.1.2 安装

```
yum install erlang
```
来自：[https://github.com/rabbitmq/erlang-rpm](https://github.com/rabbitmq/erlang-rpm)的readme.md

## 1.2 离线安装

### 1.2.1 准备

下载需要的密钥和对应的安装包

密钥下载地址：[https://dl.bintray.com/rabbitmq/Keys/rabbitmq-release-signing-key.asc](https://dl.bintray.com/rabbitmq/Keys/rabbitmq-release-signing-key.asc)

安装包下载地址：[https://github.com/rabbitmq/erlang-rpm/releases/download/v22.3.4.1/erlang-22.3.4.1-1.el7.x86_64.rpm](https://github.com/rabbitmq/erlang-rpm/releases/download/v22.3.4.1/erlang-22.3.4.1-1.el7.x86_64.rpm)

上传到服务器，进入到目录，这里上传到 `/usr`目录

```
cd /usr
```

### 1.2.2 配置密钥

```
sudo rpm --import rabbitmq-release-signing-key.asc
```

### 1.2.3 安装

```
rpm -ivh erlang-22.3.4.1-1.el7.x86_64.rpm
```

## 1.3 验证

显示版本号，并进入控制台，即成功。

```
erl
```

退出，“.”不能忘记

```
halt().
```

# 2 安装RabbitMQ (3.8.4 版本)

## 2.1 在线安装

### 2.1.1 导入签名密钥

```
sudo rpm --import https://github.com/rabbitmq/signing-keys/releases/download/2.0/rabbitmq-release-signing-key.asc
```
### 2.1.2 配置软件仓库

在 `/etc/yum.repos.`目录下添加.repo文件（例如rabbitmq.repo），在文件中添加以下内容，并保存

```
vi /etc/yum.repos.d/rabbitmq.repo
```
The following example sets up a repository that will install RabbitMQ 3.8 and targets CentOS 8:

```
[bintray-rabbitmq-server]
name=bintray-rabbitmq-rpm
baseurl=https://dl.bintray.com/rabbitmq/rpm/rabbitmq-server/v3.8.x/el/8/
gpgcheck=0
repo_gpgcheck=0
enabled=1
```
On CentOS 7 the baseurl line would be slightly different:

```
[bintray-rabbitmq-server]
name=bintray-rabbitmq-rpm
baseurl=https://dl.bintray.com/rabbitmq/rpm/rabbitmq-server/v3.8.x/el/7/
gpgcheck=0
repo_gpgcheck=0
enabled=1
```
### 2.1.3 安装

[https://dl.bintray.com/rabbitmq/rpm/rabbitmq-server](https://dl.bintray.com/rabbitmq/rpm/rabbitmq-server)中查找对应的版本，这里使用的是CentOS 7 ，所以安装地址是：

[https://dl.bintray.com/rabbitmq/rpm/rabbitmq-server/v3.8.x/el/7/noarch/rabbitmq-server-3.8.4-1.el7.noarch.rpm](https://dl.bintray.com/rabbitmq/rpm/rabbitmq-server/v3.8.x/el/7/noarch/rabbitmq-server-3.8.4-1.el7.noarch.rpm)

yum install https://dl.bintray.com/rabbitmq/rpm/rabbitmq-server/v3.8.x/el/7/noarch/rabbitmq-server-3.8.4-1.el7.noarch.rpm
## 2.2 离线安装

### 2.2.1 准备

下载对应的安装包（若选用离线，密钥在安装erlang的时候已经配置过，故这里可不再次配置）

rabbitmq以及其依赖包

socat下载地址：[http://mirror.centos.org/centos/7/os/x86_64/Packages/socat-1.7.3.2-2.el7.x86_64.rpm](http://mirror.centos.org/centos/7/os/x86_64/Packages/socat-1.7.3.2-2.el7.x86_64.rpm)

rabbitmq下载地址：[https://dl.bintray.com/rabbitmq/rpm/rabbitmq-server/v3.8.x/el/7/noarch/rabbitmq-server-3.8.4-1.el7.noarch.rpm](https://dl.bintray.com/rabbitmq/rpm/rabbitmq-server/v3.8.x/el/7/noarch/rabbitmq-server-3.8.4-1.el7.noarch.rpm)

### 2.2.2 安装

将下载的安装包上传服务器，这里上传到 `/usr`目录

```
cd /usr

rpm -ivh socat-1.7.3.2-2.el7.x86_64.rpm

rpm -ivh rabbitmq-server-3.8.4-1.el7.noarch.rpm
```
## 2.3 安装路径

默认是：`/usr/lib/rabbitmq`

```
whereis rabbitmq
```
## 2.4 开启守护进程

使用rpm安装，默认是关闭守护进程的，需要开启

```
chkconfig rabbitmq-server on
```
## 2.5 启动/停止

```
# start it back
service rabbitmq-server start

# stop the local node
service rabbitmq-server stop

# check on service status as observed by service manager
service rabbitmq-server status
```
## 2.6 放行端口
```
systemctl status firewalld

firewall-cmd --list-ports

firewall-cmd --zone=public --add-port=5672/tcp --permanent
firewall-cmd --zone=public --add-port=15672/tcp --permanent
firewall-cmd --zone=public --add-port=15674-15675/tcp --permanent
firewall-cmd --zone=public --add-port=1883/tcp --permanent

firewall-cmd --reload
```
## 2.7 用户管理

查看所有用户
```
rabbitmqctl list_users
```
添加一个用户
```
rabbitmqctl add_user admin 123456
``` 
配置权限
```
rabbitmqctl set_permissions -p "/" admin ".*" ".*" ".*" 
```
查看用户权限
```
rabbitmqctl list_user_permissions admin 
```
设置tag
```
rabbitmqctl set_user_tags admin administrator 
```
删除用户（安全起见，删除默认用户）
```
rabbitmqctl delete_user guest
```
重启即可用新账号登录

## 2.8 启用插件

### 2.8.1 Web管理
```
rabbitmq-plugins enable rabbitmq_management
```
访问：http://{ip}:15672/

默认账号密码：guest guest（这个账号只允许本机访问）

### 2.8.2 MQTT

启动MQTT插件
```
rabbitmq-plugins enable rabbitmq_mqtt
```
创建账号
```
rabbitmqctl add_user mqtt-user mqtt-password
rabbitmqctl set_permissions -p / mqtt-user ".*" ".*" ".*"
rabbitmqctl set_user_tags mqtt-user management
```
具体可查看：[https://www.rabbitmq.com/mqtt.html](https://www.rabbitmq.com/mqtt.html)

### 2.8.3 Web STOMP
```
rabbitmq-plugins enable rabbitmq_web_stomp
```
具体可查看：[https://www.rabbitmq.com/web-stomp.html](https://www.rabbitmq.com/web-stomp.html)

### 2.8.4 Web MQTT
```
rabbitmq-plugins enable rabbitmq_web_mqtt
```
具体可查看：[https://www.rabbitmq.com/web-mqtt.html](https://www.rabbitmq.com/web-mqtt.html)

### 2.8.5 TRACING
```
rabbitmq-plugins enable rabbitmq_tracing
```
消息记录追踪插件
