title: CentOS7安装Nginx、Java、Redis、MongoDB环境
date: '2020-04-27 20:13:33'
updated: '2020-05-31 00:36:01'
tags: [Redis, Nginx, Java]
permalink: /articles/2020/04/27/1587989613155.html
---
![](https://img.hacpai.com/bing/20200118.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 1 Nginx

### 1.1 安装各个依赖

```
#gcc安装，nginx源码编译需要
yum install gcc

#PCRE pcre-devel 安装，nginx 的 http 模块使用 pcre 来解析正则表达式
yum install -y pcre pcre-devel

#zlib安装，nginx 使用zlib对http包的内容进行gzip
yum install -y zlib zlib-devel

#OpenSSL 安装，强大的安全套接字层密码库，nginx 不仅支持 http 协议，还支持 https（即在ssl协议上传输http）
yum install -y openssl openssl-devel
```

### 1.2 下载

直接官网下载 [https://nginx.org/en/download.html](https://nginx.org/en/download.html)
![image.png](https://b3logfile.com/file/2020/05/image-29e44758.png)

或者使用命令下载

```
wget -c https://nginx.org/download/nginx-1.18.0.tar.gz
```

### 1.3 安装

将压缩包下载到 `/usr/local`目录下，解压出来

```
cd /usr/local

# 解压
tar -zxvf nginx-1.18.0.tar.gz

#解压后进入目录
cd nginx-1.18.0

#使用默认配置
./configure

#编译安装
make
make install
```

默认安装路径为 `/usr/local/nginx`

```
#创建软连接
ln -s /usr/local/nginx/sbin/nginx /usr/bin/nginx

#启动、停止nginx
nginx     #启动
nginx -s stop  #停止，直接查找nginx进程id再使用kill命令强制杀掉进程
nginx -s quit  #退出停止，等待nginx进程处理完任务再进行停止
nginx -s reload  #重新加载配置文件，修改nginx.conf后使用该命令，新配置即可生效

#重启nginx，建议先停止，再启动
nginx -s stop
nginx

#查看nginx进程
ps aux|grep nginx

#关闭进程
kill -s 9 进程号
```

### 1.4 开机自启动

```
#在rc.local增加启动代码即可
vi /etc/rc.local
#最后增加一行 /usr/local/nginx/sbin/nginx，增加后保存
#设置执行权限
cd /etc
chmod 755 rc.local
```

## 2 Java

### 2.1 查询系统是否已安装jdk

```
rpm -qa|grep java
#或
rpm -qa|grep jdk
#或
rpm -qa|grep gcj
```

### 2.2 卸载已安装的jdk

看第一步返回的结果操作，一般新机centOS没有这个环境

```
rpm -e --nodeps java-1.8.0-openjdk-1.8.0.131-11.b12.el7.x86_64

rpm -e --nodeps java-1.7.0-openjdk-1.7.0.141-2.6.10.5.el7.x86_64

rpm -e --nodeps java-1.8.0-openjdk-headless-1.8.0.131-11.b12.el7.x86_64

rpm -e --nodeps java-1.7.0-openjdk-headless-1.8.0.131-11.b12.el7.x86_64
```

### 2.3 验证一下是还有jdk

```
rpm -qa|grep java

java -version
```

### 2.4 下载

[https://www.oracle.com/java/technologies/javase-jdk8-downloads.html](https://www.oracle.com/java/technologies/javase-jdk8-downloads.html)、
[https://www.oracle.com/java/technologies/oracle-java-archive-downloads.html](https://www.oracle.com/java/technologies/oracle-java-archive-downloads.html)

### 2.5 安装

这里下载的是 `jdk-8u241`版本

```
cd /usr/local

#创建安装目录
mkdir /usr/local/java/

解压到安装目录
tar -zxvf jdk-8u241-linux-x64.tar.gz -C /usr/local/java/
```

### 2.6 配置环境变量

```
#打开配置文件
vi /etc/profile

#在最后追加
export JAVA_HOME=/usr/local/java/jdk1.8.0_241
export JRE_HOME=${JAVA_HOME}/jre
export CLASSPATH=.:${JAVA_HOME}/lib:${JRE_HOME}/lib
export PATH=${JAVA_HOME}/bin:$PATH

#使环境变量生效
source /etc/profile

#添加软连接
ln -s /usr/local/java/jdk1.8.0_241/bin/java /usr/bin/java

#检查版本
java -version
```

## 3 Redis

### 3.1 安装依赖

需要安装 `gcc-c++`依赖，但是之前Nginx安装时已经安装此依赖，故这里略过。

### 3.2 下载

[http://download.redis.io/releases/](http://download.redis.io/releases/)，我这里下载的是redis-5.0.8版本

### 3.3 安装

```
cd /usr/local

#创建安装目录
mkdir /usr/local/redis/

#解压
tar -zxvf redis-5.0.8.tar.gz

cd redis-5.0.8

#编译
make

#安装到指定目录
make install PREFIX=/usr/local/redis install

#创建配置文件目录
mkdir /usr/local/redis/conf/

#拷贝配置文件
cp redis.conf /usr/local/redis/conf/
```

### 3.4 配置

```
#启用密码访问
requirepass 123456

#最大连接数
maxclients 10000

#允许访问IP
bind 0.0.0.0

#表示允许后台运行
daemonize yes

#指定配置文件、运行redis
cd /usr/local/redis/bin

./redis-server /usr/local/redis/conf/redis.conf

./redis-cli -p 6379
```

### 3.5 访问

```
127.0.0.1:6379> ping
PONG
127.0.0.1:6379> shutdown
not connected> exit
```

### 3.6 查看是否启动

三种方式

```
ps -ef|grep redis

lsof -i :6379

netstat -tunple | grep 6379
```

## 4 MongoDB

### 4.1 下载

[https://fastdl.mongodb.org/linux/mongodb-linux-x86_64-4.0.18.tgz](https://fastdl.mongodb.org/linux/mongodb-linux-x86_64-4.0.18.tgz)

### 4.2 安装

上传压缩包到 `/usr/local`目录

```
cd /usr/local

#解压
tar -zxvf mongodb-linux-x86_64-4.0.18.tgz

#重命名
mv mongodb-linux-x86_64-4.0.18 mongodb
```

### 4.3 配置

```
#进入mongodb目录
cd /usr/local/mongodb

#创建db目录和日志目录
mkdir db

mkdir logs

#创建mongo.conf文件
cd bin
vi mongo.conf
```

配置文件内容如下

```
## content
systemLog:
  destination: file
  logAppend: true
  path: /usr/local/mongodb/logs/config.log
 
# Where and how to store data.
storage:
  dbPath: /usr/local/mongodb/db/
  directoryPerDB: true

  journal:
    enabled: true
# how the process runs
processManagement:
  fork: true
  pidFilePath: /usr/local/mongodb/logs/configsvr.pid
 
# network interfaces
net:
  port: 27017
  bindIp: 0.0.0.0
 
#operationProfiling:
#replication:
#    replSetName: bt_main   
security:
  authorization: disabled
  javascriptEnabled: false

#sharding:
#    clusterRole: shardsvr
```

允许的IP为任意IP

### 4.4 测试

```
#创建软连接
ln -s /usr/local/mongodb/bin/mongod /usr/bin/mongod
ln -s /usr/local/mongodb/bin/mongo /usr/bin/mongo

#启动
mongod --config mongo.conf

#连接
mongo

#退出
exit

#关闭
mongod --config mongo.conf --shutdown
```

### 4.5 创建用户

```
#切换到admin数据库
use admin

#给admin数据库分配用户名和密码，并设置权限为root，超级权限
db.createUser({user:"root",pwd:"123456",roles:["root"]})

//插入数据
db.admin.insert({name:"mongo"})
```

exit退出，同时修改配置文件,`authorization: enabled`，启动密码访问

```
## content
systemLog:
  destination: file
  logAppend: true
  path: /usr/local/mongodb/logs/config.log
 
# Where and how to store data.
storage:
  dbPath: /usr/local/mongodb/db/
  directoryPerDB: true

  journal:
    enabled: true
# how the process runs
processManagement:
  fork: true
  pidFilePath: /usr/local/mongodb/logs/configsvr.pid
 
# network interfaces
net:
  port: 27017
  bindIp: 0.0.0.0
 
#operationProfiling:
#replication:
#    replSetName: bt_main   
security:
  authorization: enabled
  javascriptEnabled: false

#sharding:
#    clusterRole: shardsvr
```
