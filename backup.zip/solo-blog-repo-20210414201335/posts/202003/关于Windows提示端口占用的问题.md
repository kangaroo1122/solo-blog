title: 关于Windows提示端口占用的问题
date: '2020-03-17 21:45:22'
updated: '2020-03-17 21:46:21'
tags: [system]
permalink: /articles/2020/03/17/1584452722001.html
---
![](https://img.hacpai.com/bing/20180105.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

运行springboot jar包，提示端口占用，原本想着操作三连
```
//1、查看端口占用进程
netstat -ano | findstr 8086
//2、找到listening后边的进程号
//3、KILL进程
taskkill -PID 进程号 -F
```
然而，第一步就没走通，WTF？提示端口被占用同时使用netstat -ano又得不到任何该端口的信息？！

俗话说，重启能解决90%的问题，ok，走你！

然后，启动jar依然提示端口占用？？

![u24167560453411095524fm26gp0.jpg](https://img.hacpai.com/file/2020/03/u24167560453411095524fm26gp0-482df95d.jpg)

以管理员身份进入cmd，运行如下命令
```
netsh winsock reset
```
重启网络成功后，重启电脑，嗯，可以用了。
