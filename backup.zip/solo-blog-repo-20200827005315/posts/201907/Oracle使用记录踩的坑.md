title: Oracle使用记录【踩的坑】
date: '2019-07-22 16:56:13'
updated: '2020-06-02 16:26:53'
tags: [Oracle]
permalink: /articles/2019/07/22/1563785773680.html
---
![](https://img.hacpai.com/bing/20180929.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 一、下载安装

参考blog：https://blog.csdn.net/wei1992_6/article/details/60054727 。

## 二、错误记录

### 2.1 默认密码

system默认:manager
sys默认:change_on_install
使用SQL Plus登录数据库时，system使用密码manager可直接登录。
但如果是sys用户，密码必须加上as sysdba，即完整密码为：change_on_install as sysdba
sqlplus: alter user dbaName account unlock; 解锁登陆账号
sqlplus: alter user dbaName account lock;  冻结登陆账号
sqlplus: alter user dbaName identified by "password"; 修改登录账号密码

### 2.2 SCOTT用户不存在或已锁定

参考：https://www.cnblogs.com/hjweifans/p/6891837.html

### 2.3 ORA-28547：Connection to server failed,probable Oracle Net admin error

Navicat Premium默认的oci.dll文件版本不正确，下载地址 [Instant Client for Microsoft Windows (x64)](https://www.oracle.com/database/technologies/instant-client/winx64-64-downloads.html) ，下载以后，在Navicat中替换dll文件，重启Navicat。参考：https://blog.csdn.net/qq_40238199/article/details/85157529 ，https://blog.csdn.net/gxp1182893781/article/details/79815573

### 2.4 ORA-24344：success with compilation error

把数据库表名、表字段名，序列名称，触发器名称等通通改成大写。

### 2.5 ORA-04098：触发器无效且未通过重新验证

一般是触发器编写逻辑有误。

### 2.6 ORA-01861：文字与格式字符串不匹配

插入的时间格式与数据库现有的时间格式不一致，使用TO_DATE格式化一下插入语句中的时间格式。

### 2.7 ORA-01002: 提取违反顺序

PTC的Thingworx平台中，调用SQL执行Oracle数据库插入时，需要将SQL的执行模式选择成command方式，才能执行插入，默认的query方式，则会报出此错误。

### 2.8 ORA-12505：TNS:listener does not currently know of SID given in connect descriptor

SID不正确。

* 在Windows系统中，可以查看注册表信息：HKEY_LOCAL_MACHINE\SOFTWARE\Oracle\KEY_OraDb11g_home1中查看ORACLE_SID的值；
* 或者是查看Oracle安装路径下的NETWORK/ADMIN/listener.ora文件；
* cmd命令行，登陆数据库

```cmd
SQL>conn / as sysdba
SQL>select instance_name from v$instance;
```

## 三、自增主键（序列+触发器）

创建序列和触发器以后，insert不再需要手动给主键赋值。

### 3.1 创建序列

```sql
----SEQ_T_MONTH_DAY_INSERT是序列名称
create sequence SEQ_T_MONTH_DAY_INSERT minvalue 1 maxvalue 9999999999999 increment by 1 start with 1;
```

也可以用图形化工具Navicat来创建，选中表>其它>序列，根据提示填写即可。

### 3.2 创建触发器

```sql
----TRI_T_MONTH_DAY_INSERT是触发器名称
----T_MONTH_DAY是目标表名称
----SEQ_T_MONTH_DAY_INSERT是序列名称
----new.ID的ID是目标表主键
CREATE OR REPLACE TRIGGER TRI_T_MONTH_DAY_INSERT 
before INSERT ON "T_MONTH_DAY" FOR each ROW 
BEGIN
  SELECT SEQ_T_MONTH_DAY_INSERT.nextval INTO :new.ID FROM dual;
END;
```

> 注：
> 序列名，触发器名都最好用大写，防止一些莫名其妙的错误。

### 3.3 导出所有序列

导出所有序列的创建语句，保留当前的起始序号

方式一：

```sql
SELECT
	'CREATE SEQUENCE 数据库名.' || SEQUENCE_NAME || ' MINVALUE ' || MIN_VALUE || ' MAXVALUE ' || MAX_VALUE || ' START WITH ' || LAST_NUMBER || ' INCREMENT BY ' || INCREMENT_BY ||' ;' 
FROM
	DBA_SEQUENCES 
WHERE
	SEQUENCE_OWNER = '数据库名';
```

方式二：

```sql
SELECT
	dbms_metadata.get_ddl ( 'SEQUENCE', u.object_name ) 
FROM
	user_objects u 
WHERE
	object_type = 'SEQUENCE'
```

## 待续......
