title: CentOS 7安装配置FTP服务器
date: '2020-11-13 11:03:47'
updated: '2020-11-13 11:09:45'
tags: [FTP, Nginx]
permalink: /articles/2020/11/13/1605236627778.html
---
![](https://b3logfile.com/bing/20181026.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 1 下载安装

地址：[http://mirror.centos.org/centos/7/os/x86_64/Packages/vsftpd-3.0.2-27.el7.x86_64.rpm](http://mirror.centos.org/centos/7/os/x86_64/Packages/vsftpd-3.0.2-27.el7.x86_64.rpm)

上传离线包到 `/usr`目录下，安装vsftpd服务

```bash
cd /usr

rpm -ivh vsftpd-3.0.2-27.el7.x86_64.rpm
```

### 2 全局配置

**去掉配置文件里的注释行**

```bash
mv /etc/vsftpd/vsftpd.conf /etc/vsftpd/vsftpd.conf.bak

grep -v "#" /etc/vsftpd/vsftpd.conf.bak > /etc/vsftpd/vsftpd.conf
```

**配置firewalld防火墙开放2231和45000-49000端口**

```bash
systemctl status firewalld

firewall-cmd --list-ports

firewall-cmd --permanent --add-port=2231/tcp

firewall-cmd --permanent --add-port=45000-49000/tcp

firewall-cmd --reload
```

### 3 配置虚拟用户

**创建用于FTP认证的用户数据库文件**

```bash
vi /etc/vsftpd/vuser.txt
```

*注：第一行用户名，第二行密码，依此类推*

```bash
ftpuser
123456
```

明文信息不安全，需要使用db_load命令用哈希（hash）算法将明文信息转换成数据文件，然后将明文信息文件删除。

```bash
db_load -T -t hash -f /etc/vsftpd/vuser.txt /etc/vsftpd/vuser.db

chmod 600 /etc/vsftpd/vuser.db

rm -f /etc/vsftpd/vuser.txt
```

**创建虚拟用户映射的系统本地用户和FTP根目录**

```bash
#创建用户
useradd -d /home/ftpuser -s /sbin/nologin ftpuser

#文件夹权限
chmod -Rf 755 /home/ftpuser/
```

**shells更新**

```bash
vi /etc/shells
```

新增

```bash
/sbin/nologin
```

**建立用于支持虚拟用户的PAM文件**

新建一个用于虚拟用户认证的PAM文件vsftpd.vu，其中PAM文件内的“db=”参数为使用db_load命令生成的账户密码数据文件的路径，但不用写数据文件的后缀。

```bash
vi /etc/pam.d/vsftpd.vu
```

内容

```bash
auth     required     pam_userdb.so  db=/etc/vsftpd/vuser
account  required     pam_userdb.so  db=/etc/vsftpd/vuser
```

**设置权限**

```bash
mkdir /etc/vsftpd/vusers_dir

vi /etc/vsftpd/vusers_dir/ftpuser
```

内容

```bash
anon_upload_enable=YES
anon_mkdir_write_enable=YES
anon_other_write_enable=YES
```

### 4 修改配置文件

```bash
vi /etc/vsftpd/vsftpd.conf
```

内容

```bash
anonymous_enable=NO
# 匿名用户上传文件的umask值
anon_umask=022
local_enable=YES
# 开启虚拟用户模式
guest_enable=YES
#指定虚拟用户对应的系统用户
guest_username=ftpuser
# 允许对FTP根目录执行写入操作
allow_writeable_chroot=YES
write_enable=YES
local_umask=022
#指定用户的FTP根目录
local_root=/home/ftpuser
dirmessage_enable=YES
xferlog_enable=YES
connect_from_port_20=YES
xferlog_std_format=YES
listen_port=2231
listen=NO
listen_ipv6=YES
# 指定PAM文件
pam_service_name=vsftpd.vu
userlist_enable=YES
tcp_wrappers=YES
# 指定虚拟用户配置文件目录
user_config_dir=/etc/vsftpd/vusers_dir
pasv_min_port=45000
pasv_max_port=49000
```

### 5 vsftpd常用命令

```bash
#开机自启
chkconfig vsftpd on
#启动
service vsftpd start
#重启
service vsftpd restart
#查看状态
service vsftpd status
```
