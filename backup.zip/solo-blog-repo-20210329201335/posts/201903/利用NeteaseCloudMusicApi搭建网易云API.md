title: 利用 NeteaseCloudMusicApi 搭建网易云 API
date: '2019-03-18 14:26:43'
updated: '2020-03-25 00:22:21'
tags: [Git, Node.js, 网易云]
permalink: /articles/2019/03/18/1552890403559.html
---
![](https://img.hacpai.com/bing/20190117.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

今天，自己按照&nbsp;&nbsp;[NeteaseCloudMusicApi](https://github.com/Binaryify/NeteaseCloudMusicApi)&nbsp;&nbsp;的官方文档在Ubuntu18.04上成功搭建了一个本地网易云API，现做以下记录以备忘。
# 1.安装git
参考这篇blog&nbsp;&nbsp;[Ubuntu下git的安装与使用](https://www.cnblogs.com/lxm20145215----/p/5905765.html)，只是最后上传公钥是弄到Github上，最后使用命令
```
ssh -T git@github.com
```
就可以查看。
# 2.安装nodejs
参考这篇blog&nbsp;&nbsp;[ubuntu18.04下安装node](https://www.cnblogs.com/guanine/p/9392411.html),但是却卡在了安装n，后来查到了这里&nbsp;&nbsp;[Ubuntu安装最新版nodejs](https://www.cnblogs.com/flying_bat/p/8671816.html)，然后直接
```
sudo n 9.10
```
而不是
```
sudo n stable
```
或者是校园网的原因，记录一下。
# 3.搭建API
### 官方教程
#### 安装

```shell
$ git clone git@github.com:Binaryify/NeteaseCloudMusicApi.git
$ npm install
```
安装出现权限问题时，用sudo。
#### 运行

```shell
$ node app.js
```
>  注：
```
$ npm install
$ node app.js
```
这两个命令，需要到/home/kangaroo/NeteaseCloudMusicApi目录下执行才能生效，如图：

![image.png](https://img.hacpai.com/file/2019/03/image-ae83e2fc.png)

![image.png](https://img.hacpai.com/file/2019/03/image-2561ecfb.png)

# 使用forever让node.js持久运行
```
npm install forever -g   #安装
forever start app.js  #启动应用
forever stop app.js  #关闭应用
forever restartall  #重启所有应用

#输出日志和错误
forever start -l forever.log -o out.log -e err.log app.js   

# 指定forever信息输出文件，当然，默认它会放到~/.forever/forever.log
forever start -l forever.log app.js  

# 指定app.js中的日志信息和错误日志输出文件，  
# -o 就是console.log输出的信息，-e 就是console.error输出的信息
forever start -o out.log -e err.log app.js 

# 追加日志，forever默认是不能覆盖上次的启动日志，  
# 所以如果第二次启动不加-a，则会不让运行  
forever start -l forever.log -a app.js

# 监听当前文件夹下的所有文件改动（不太建议这样）  
forever start -w app.js  

# 显示所有运行的服务 
forever list  

######停止操作

# 停止所有运行的node App  
forever stopall  
  
# 停止其中一个node App  
forever stop app.js  

# 当然还可以这样  
# forever list 找到对应的id，然后：  
forever stop [id]

# 开发环境下  
NODE_ENV=development forever start -l forever.log -e err.log -a app.js  
# 线上环境下  
NODE_ENV=production forever start -l ~/.forever/forever.log -e ~/.forever/err.log -w -a app.js
#上面加上NODE_ENV为了让app.js辨认当前是什么环境用的
```
