title: Nginx+Tomcat 配置不同二级域名访问Tomcat中的对应项目到Nginx给网站安装SSL证书
date: '2019-03-23 11:10:33'
updated: '2020-03-25 00:22:08'
tags: [Tomcat, Nginx, SSL]
permalink: /articles/2019/03/23/1553310633858.html
---
![](https://img.hacpai.com/bing/20180130.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 1.Tomcat 配置不同二级域名
进入Tomcat 的安装目录conf目录下，找到server.xml文件打开，找到host节点。复制host节点并且编辑里面的内容：
```xml
<!--blog.kangaroohy.top-->
<Host name="blog.kangaroohy.top"  appBase="webapps" unpackWARs="true" autoDeploy="true">
	<Context path="" docBase="/usr/tomcat/webapps/solo" debug="0"/>
        
	<Valve className="org.apache.catalina.valves.AccessLogValve" directory="logs"
		prefix="localhost_access_log" suffix=".txt"
		pattern="%h %l %u %t &quot;%r&quot; %s %b" />

</Host>
```
其中，Host节点的name就是网址，Context节点的docBase就是项目的绝对路径。
有多少项目，就配置多少Host节点。通过这种方式，即可在同一个Tomcat中部署多个Webapp。重启服务器，在云服务器安全组添加8080端口外网访问规则，即可通过`http://blog.kangaroohy.top:8080`访问项目。接下来再配置Nginx。
## 2.Nginx安装及配置
### 安装
在Ubuntu系统下，直接
```
$sudo apt-get install nginx
```
即可安装Nginx，安装完后，文件结构大致为：

*   所有的配置文件都在`/etc/nginx`下，并且每个虚拟主机已经安排在了/etc/nginx/sites-available下
*   程序文件在`/usr/sbin/nginx`
*   日志放在`/var/log/nginx`中
*   并已经在`/etc/init.d/`下创建了启动脚本nginx
*   默认的虚拟主机的目录设置在了`/var/www/nginx-default` (有的版本 默认的虚拟主机的目录设置在了`/var/www`, 请参考`/etc/nginx/sites-available`里的配置)
### 配置
在配置solo博客的时候，直接用了solo官方的配置，先找到nginx的配置目录（也可以通过`whereis nginx`命令得知安装目录），也是进入到`/etc/nginx`下的配置文件`nginx.conf`的http节点中作如下配置：
```
upstream blog {
    server localhost:8080; 
}

server {
    listen       80;
    server_name  blog.kangaroohy.top; 

    access_log off;

    location / {
        proxy_pass http://blog$request_uri;
        proxy_set_header  Host $host:$server_port;
        proxy_set_header  X-Real-IP  $remote_addr;
        client_max_body_size  10m;
    }
}
```
进入nginx安装目录sbin下，输入命令`./nginx -t`，看到如下显示  
```
nginx.conf syntax is ok  
nginx.conf test is successful  
```
说明配置文件正确！重启nginx后，通过`http://blog.kangaroohy.top`成功访问。<br/>注：

* 在启动时遇到了80端口占用问题，是由于Nginx自身占用导致，直接kill掉nginx再启动就搞定。
```
ps -ef | grep nginx
```
从容停止   kill -QUIT 主进程号
快速停止   kill -TERM 主进程号
强制停止   kill -9 nginx
```
sudo /usr/sbin/nginx
```
* 配置完nginx后，修改安全组的8080端口为80端口，同时增加443端口，为下边配置SSL准备。
## 3.Nginx服务器安装SSL证书
### 申请SSL
由于用的是阿里云，所以直接在阿里云申请的免费SSL [免费型 DV SSL](https://common-buy.aliyun.com/?spm=5176.2020520154.cas.3.7ee456a75ylVZx&commodityCode=cas#/buy)，系统签发后，下载Nginx版本并进行配置。
### 配置
在Nginx的`/etc/nginx`目录下新建`cert`目录，并把下载好的证书上传到该目录下，名字可自定义，与server里的名字相同即可。进入到`/etc/nginx`下的配置文件`nginx.conf`的http节点中作如下调整：
```
upstream blog{
	server localhost:8080;
}

server {
	listen 443;
	server_name blog.kangaroohy.top;
	ssl on;
	root html;
	index index.html index.htm;
	ssl_certificate  cert/blog.kangaroohy.top.pem;
	ssl_certificate_key cert/blog.kangaroohy.top.key;
	ssl_session_timeout 5m;
	ssl_ciphers ECDHE-RSA-AES128-GCM-SHA256:ECDHE:ECDH:AES:HIGH:!NULL:!aNULL:!MD5:!ADH:!RC4;
	ssl_protocols TLSv1 TLSv1.1 TLSv1.2;
	ssl_prefer_server_ciphers on;

	location / {
		root html;
		index index.html index.htm;
		proxy_pass http://blog$request_uri;
		proxy_set_header  Host $host:$server_port;
		proxy_set_header  X-Real-IP  $remote_addr;
		client_max_body_size  10m;
	}
}

server{
	listen       80;
	server_name  blog.kangaroohy.top; 
	rewrite ^/(.*)$ https://blog.kangaroohy.top/$1 permanent;
}
```
再次检查是否配置没问题，然后重启Nginx，访问 [http://blog.kangaroohy.top](http://blog.kangaroohy.top) 自动跳转到`https://blog.kangaroohy.top`

> 注：
在给solo配置SSL时，还需要把solo的latke.properties配置文件改改
```
#### Server ####
# Browser visit protocol
serverScheme=https
serverHost=blog.kangaroohy.top
```
![image.png](https://img.hacpai.com/file/2019/03/image-6da4bed6.png)

成功给solo配置SSL！
