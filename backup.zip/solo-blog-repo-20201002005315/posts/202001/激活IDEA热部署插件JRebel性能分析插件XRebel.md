title: 激活IDEA热部署插件——JRebel, 性能分析插件——XRebel
date: '2020-01-05 15:13:14'
updated: '2020-01-10 09:55:01'
tags: [JRebel, 激活, XRebel]
permalink: /articles/2020/01/05/1578208394200.html
---
![](https://img.hacpai.com/bing/20190818.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 1 准备

- 激活代理软件下载：https://github.com/ilanyu/ReverseProxy/releases ，选择对应的操作系统下载软件
- 激活地址，任意一个

```
http://127.0.0.1:8888/88414687-3b91-4286-89ba-2dc813b107ce
http://127.0.0.1:8888/ff47a3ac-c11e-4cb2-836b-9b2b26101696
http://127.0.0.1:8888/11d221d1-5cf0-4557-b023-4b4adfeeb36a
```

- 打开 IDEA 插件中心，搜索 JRebel 下载并安装插件，安装完，再更新一下这个插件，就会包含两个插件了。只是激活需要单独操作，见下：

## 2 激活
### 2.1 JRebel

- 打开之前下载好的激活代理软件，直到完成所有操作以后，再关闭此软件
- 首次安装就会提示激活，根据提示进入到激活面板
  不是首次安装，进入方式：File>Setting>JRebel>Change license
  ![image.png](https://img.hacpai.com/file/2020/01/image-0f04fef9.png)
- 复制上边提供的三个激活地址之一，输入任意邮箱，点击同意并激活
- 将其设置为离线模式，File>Setting>JRebel>work offline
- 激活完成，此时可以关闭激活代理软件
### 2.2 XRebel
- 打开之前下载好的激活代理软件，直到完成所有操作以后，再关闭此软件
- 用XRebel随便启动一个springboot项目，访问：http://localhost:8080/xrebel ，会提示输入license
- 选择我已有license选项
- 复制上边提供的三个激活地址之一，输入任意邮箱，点击同意并激活
- 将其设置为离线模式，步骤如下：

![image.png](https://img.hacpai.com/file/2020/01/image-929140c1.png)

我这里的截图已经是离线模式
