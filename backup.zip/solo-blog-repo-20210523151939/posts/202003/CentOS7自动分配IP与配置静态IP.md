title: CentOS 7 自动分配IP与配置静态IP
date: '2020-03-24 17:39:02'
updated: '2020-04-27 10:18:58'
tags: [CentOS, system]
permalink: /articles/2020/03/24/1585042742381.html
---
![](https://img.hacpai.com/bing/20190114.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

使用VMware Worksstation安装CentOS 7.x的虚拟机后，命令行输入

```
ip addr
```

没有自动分配IP，一般情况下，是由于虚拟之后的系统没有默认开启网卡（ONBOOT=no）,此时需要打开这个选项。

## 1 自动分配IP

### 第一步

打开ens33网卡的配置（这里不一定是33，具体情况，请看 `ip addr`的反馈）

```
vi /etc/sysconfig/network-scripts/ifcfg-ens33
```

### 第二步

将ONBOOT的值改成yes，如下：

```
TYPE=Ethernet
PROXY_METHOD=none
BROWSER_ONLY=no
BOOTPROTO=dhcp
DEFROUTE=yes
IPV4_FAILURE_FATAL=no
IPV6INIT=yes
IPV6_AUTOCONF=yes
IPV6_DEFROUTE=yes
IPV6_FAILURE_FATAL=no
IPV6_ADDR_GEN_MODE=stable-privacy
NAME=ens33
UUID=c8fd958e-0fdd-47d2-a515-9a7e56ab82cd
DEVICE=ens33
ONBOOT=yes
```

### 第三步

重启网络服务

```
sudo service network restart
```

再次输入

```
ip addr
```

即可查看分配的IP地址。

## 2 配置静态IP

动态分配，会导致虚拟机的IP地址时不时的自己改变，由于自己的redis和其他的各种数据库都是装在虚拟机，导致开发中经常遇到程序突然连不上redis或其他的服务器，故有必要直接给其分配静态IP。

### 第一步

打开VMware菜单栏，编辑 -> 虚拟网络编辑器，查看网关ip地址

![image.png](https://img.hacpai.com/file/2020/03/image-5b81a9af.png)

查看可以分配的ip地址段、子网掩码

![image.png](https://img.hacpai.com/file/2020/03/image-62c1fc57.png)

### 第二步

重新打开ens33网卡的配置

```
vi /etc/sysconfig/network-scripts/ifcfg-ens33
```

做如下配置

```
TYPE=Ethernet
PROXY_METHOD=none
BROWSER_ONLY=no
BOOTPROTO=static #从dhcp动态分配改成static静态连接
DEFROUTE=yes
IPV4_FAILURE_FATAL=no
IPV6INIT=yes
IPV6_AUTOCONF=yes
IPV6_DEFROUTE=yes
IPV6_FAILURE_FATAL=no
IPV6_ADDR_GEN_MODE=stable-privacy
NAME=ens33
UUID=c8fd958e-0fdd-47d2-a515-9a7e56ab82cd
DEVICE=ens33
ONBOOT=yes #开机启动配置
IPADDR=192.168.213.136 #从可以分配的地址段中选择一个作为虚拟机的IP
NETMASK=255.255.255.0 #子网掩码，第一步获得
GATEWAY=192.168.213.2 #网关IP，和VMware8一致，第一步获得
```

### 第三步

重启网络服务

```
sudo service network restart
```

再次输入

```
ip addr
```

即可查看自己分配的静态IP地址。

ping一下百度，ping -c 4 112.80.248.76

![image.png](https://img.hacpai.com/file/2020/03/image-717089b5.png)

分配成功

如果yum下载软件的时候，出现 Could not retrieve mirrorlist，需要在上述配置最后再加一行

```
DNS1=8.8.8.8
```

### 附
查看防火墙状态
```
systemctl status firewalld
```
查看已开放的端口
```
firewall-cmd --list-ports
```
开放单个端口
```
firewall-cmd --zone=public --add-port=6379/tcp --permanent
```
开放端口段
```
firewall-cmd --zone=public --add-port=6369-7369/tcp --permanent
```
重启防火墙
```
firewall-cmd --reload
```
关闭端口（关闭后需要要重启防火墙才生效）
```
firewall-cmd --zone=public --remove-port=3338/tcp --permanent
```
开机启动防火墙
```
systemctl enable firewalld
```
开启防火墙
```
systemctl start firewalld
```
禁止防火墙开机启动
```
systemctl disable firewalld
```
停止防火墙
```
systemctl stop firewalld
```
