title: JS使用日常
date: '2019-09-16 14:36:34'
updated: '2020-03-25 00:16:55'
tags: [JS]
permalink: /articles/2019/09/16/1568615794584.html
---
![](https://img.hacpai.com/bing/20190727.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 1 JS获取当月第一天和最后一天
```js
	//获取当前月份第一天
	var date = new Date();
	date.setDate(1);	//定位时间到1号
	var months = date.getMonth() + 1;
	var days = date.getDate();
	if (months < 10) {
		months = '0' + months;
	}
	months = months + '';
	if (days < 10) {
		days = '0' + days;
	}
	days = days + '';
	var datas = date.getFullYear() + '-' + months + '-' + days;
	console.log(datas)
        // var date = new Date();

	//获取当月最后一天
	var currentMonth = date.getMonth();
	var nextMonth = ++currentMonth;
	var nextMonthFirstDay = new Date(date.getFullYear(), nextMonth, 1);
	var oneDay = 24 * 60 * 60 * 1000;
	var lastTime = new Date(nextMonthFirstDay - oneDay);
	var month = lastTime.getMonth() + 1;
	var day = lastTime.getDate();
	if (month < 10) {
		month = '0' + month;
	}
	month =  month + '';
	if (day < 10) {
		day = '0' + day;
	}
	day = day + '';
	//当月最后一天
	var data = date.getFullYear() + '-' + month + '-' + day;
	console.log(data)
```
在实际开发中，使用这个则是为了动态获取当前月的天数。
## 2 时间戳转日期格式
```js
function timestampToTime(timestamp) {
	var date = new Date(timestamp * 1000); //时间戳为10位需*1000，时间戳为13位的话不需乘1000
	Y = date.getFullYear() + '-';
	M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
	D = date.getDate() + ' ';
	h = date.getHours() + ':';
	m = (date.getMinutes() < 10 ? '0' + (date.getMinutes()) : date.getMinutes()) + ':';
	s = (date.getSeconds() < 10 ? '0' + (date.getSeconds()) : date.getSeconds());
	return Y + M + D + h + m + s;
}
```
## 3 合并数组中属性值相同的项并把属性值相加
### 3.1 参见：[js篇-数组合并其中属性值相同的项目且属性值相加](https://www.cnblogs.com/keleyz/p/10237875.html)
项目背景是：var a = [{id:1,num:"12"},{id:2,num:"13"},{id:3,num:"3"},{id:2,num:"16"},{id:5,num:"14"},{id:1,num:"14"}]

要求输出：a = [{id:1,num:"26"},{id:2,num:"29"},{id:3,num:"3"},{id:5,num:"14"}],id相同项合并且 num 相加。

现在想到的一个思路是双重循环a 数组，现将a 数组里面 id 相同项的 num 值相加，并记录id 相同项目的下标值（从后面记录），最后再删除相同项的下标。
```js
	var a = [{id:1,num:"12"},{id:2,num:"13"},{id:3,num:"3"},{id:2,num:"16"},{id:5,num:"14"},{id:1,num:"14"}]
	//要求输出 a = [{id:1,num:"26"},{id:2,num:"29"},{id:3,num:"3"},{id:5,num:"14"}],id相同项合并且 num 相加

	var b = []//记录数组a中的id 相同的下标
	for(var i = 0; i < a.length;i++){
		for(var j = a.length-1;j>i;j--){
			if(a[i].id == a[j].id){
				a[i].num = (a[i].num*1 + a[j].num*1).toString()
				b.push(j)
			}
		}
	}
	console.log(b)
	for(var k = 0; k<b.length;k++){
		a.splice(b[k],1)
	}
	console.log(a)
```
### 3.2 实际开发
在thingworx开发中遇到了相同的问题，处理前数据如下：

| COLOR_CODE | CAR_CODE | FALST_NUMBER |
| --- | --- | --- |
| PB8 |  SC7157 |  1 |
| RF4 |  SC7155 |  2 |
| WC2 |  SC7157 |  1 |
| PB8 |  SC7157 |  1 |
| LRG |  SC7155 |  1 |
| WC2 |  SC7157 |  1 |
| LRG |  SC7155 |  1 |
| LWJ |  SC7155 |  1 |
| WC2 |  SC7155 |  1 |
| WC2 |  SC7157 |  1 |
| WC2 |  SC7155 |  1 |
| WC2 |  SC7155 |  1 |
| LRG |  SC7155 |  1 |
| WC2 |  SC7155 |  1 |
| WC2 |  SC7157 |  1 |
| RF4 |  SC7155 |  1 |
| LRG |  SC7155 |  1 |
| PB8 |  SC7157 |  1 |
| WC2 |  SC7155 |  1 |
| WC2 |  SC7157 |  1 |
| LRG |  SC7155 |  1 |
| PB8 |  SC7157 |  1 |
| LWJ |  SC7155 |  1 |
| WC2 |  SC7155 |  1 |
| WC2 |  SC7157 |  1 |
| WC2 |  SC7155 |  1 |
| WC2 |  SC7157 |  1 |
| LBE |  SC7155 |  1 |
处理后数据如下：

| COLOR_CODE | CAR_CODE | FALST_NUMBER |
| --- | --- | --- |
| PB8 |  SC7157 |  4 |
| RF4 |  SC7155 |  3 |
| WC2 |  SC7157 |  7 |
| LRG |  SC7155 |  5 |
| LWJ |  SC7155 |  2 |
| WC2 |  SC7155 |  7 |
| LBE |  SC7155 |  1 |
在Thingworx中实现的逻辑相对来说更加简单，是因为它的底层做了一次封装。
```js
for (var i = 0; i < result.rows.length; i++) {
	for (var j = result.rows.length - 1; j > i; j--) {
		if (result.rows[i].COLOR_CODE == result.rows[j].COLOR_CODE && result.rows[i].CAR_CODE == result.rows[j].CAR_CODE) {
			result.rows[i].FALST_NUMBER += result.rows[j].FALST_NUMBER;
            		result.RemoveRow(j);
		}
	}
}
```
## 4 JS中判断是否是日期格式
### 4.1 用Date.parse
Date.parse() : 返回1970年1月1日午夜到指定日期（字符串）的毫秒数。
```js
//如果用net Date()转换后，得到的不是日期/时间，那么Date.parse()返回的是NaN;
var str="aijquery";
var date=new Date(str);
console.log(Date.parse(date)); //输出的是NaN
//并且可以用if来判断了：
if(!isNaN(Date.parse(date))){
    //是日期/时间
}else{
    //不是日期/时间
}
```
### 4.2 用正则
```js
//比如要验证格式为2019-03-31,比如“粗糙”的写法：
var reg=/^\d{4}-\d{2}-\d{2}$/gi;
 
//下面来给大家分享个“严格”的：
var reg=/^[1-2]\d{3}\-(0[1-9]|1[0-2])\-(0[1-9]|[1-2][0-9]|3[0-1])$/gi;
//上面这个正则，要求字符串，必须符合“yyyy-MM-dd”的格式，也就是月和日必须为两位数
 
//如果加上月或日是一位数的判断，可以改为：
var reg=/^[1-2]\d{3}\-(0?[1-9]|1[0-2])\-(0?[1-9]|[1-2][0-9]|3[0-1])$/gi;
 
//如果要验时间的话，如16:30:58
var reg=/^(0?[1-9]|1[0-9]|2[0-3]):(0?[0-9]|[1-5][0-9]):([0-5][0-9])$/gi;
```
## 5 JS中 周 日期的获取
### 5.1 获得指定月有几个自然周
```js
function getWeeks(year, month) {//getWeeks(2019, 9)：2019年9月
	var d = new Date();
	// 该月第一天
	d.setFullYear(year, month - 1, 1);
	var w1 = d.getDay();
	if (w1 == 0) w1 = 7;
	// 该月天数
	d.setFullYear(year, month, 0);
	var dd = d.getDate();
	// 第一个周一
	var d1;
	if (w1 != 1) d1 = 7 - w1 + 2;
	else d1 = 1;
	var week_count = Math.ceil((dd - d1 + 1) / 7);
	return week_count;
}
```
### 5.2 获得指定月第几周的周一日期
```js
function getMondayTime(year, month, weekday) {//getMondayTime(2019, 9, 3)：2019年9月第3周 周一
	var d = new Date();
	// 该月第一天
	d.setFullYear(year, month - 1, 1);
	var w1 = d.getDay();
	if (w1 == 0) w1 = 7;
	// 该月天数
	d.setFullYear(year, month, 0);
	var dd = d.getDate();
	// 第一个周一
	var d1;
	if (w1 != 1) d1 = 7 - w1 + 2;
	else d1 = 1;
	var monday = d1 + (weekday - 1) * 7;
	d.setDate(monday);
	return d;
}
```
### 5.3 获得指定日期所在周 周一
```js
function getMonDate(start) {//start：Date类型
	var d = start;
	var day = d.getDay();
	var date = d.getDate();
	if (day == 1)
		return d;
	if (day == 0)
		d.setDate(date - 6);
	else
		d.setDate(date - day + 1);
	return d;
}
```
### 5.4 获得指定日期所在周 周日
```js
function getSunDate(end) {//end：Date类型
	var d = end;
	var day = d.getDay();
	var date = d.getDate();
	if (day == 0)
		return d;
	else
		d.setDate(date + 7 - day);
	return d;
}
```
