title: QQ 音乐等各类 API 食用指南
date: '2019-09-17 19:35:25'
updated: '2020-03-25 00:15:52'
tags: [one一个, API, QQ音乐, 无损]
permalink: /articles/2019/09/17/1568720125758.html
---
![](https://img.hacpai.com/bing/20190514.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

所有请求的域名为：http://api.kangaroohy.com/ ，所有请求都为 GET 请求。此 API 仅作为毕设音乐源支持，需要做音乐相关毕设的，可以联系我为其提供 API 支持。禁止商业用途，一经发现，永久拉黑。

## 0 更新

- 2020-02-09

> 更换域名.top到.com

- 2019-12-20

> 音乐 API 失效，待修复

- 2019-11-29

> 新增咪咕音乐，只支持搜索歌曲

- 2019-10-29

> 1.新增 token 传输方式，可将 token 放入 header 中进行请求，推荐使用
> 2.保留 token 的 url 传参方式，与其他请求参数类似

- 2019-10-24

> 1.新增 SQ（flac）、HQ（320）音质获取
> 2.移除 96（m4a）音质

- 2019-09-25

> 新增获取 token 授权码

- 2019-09-24

> 支持 GET 跨域请求

## 1 QQ 音乐

### 1.1 获取音乐详情

接口地址： `http://api.kangaroohy.com/tencent/song`
请求示例： `http://api.kangaroohy.com/tencent/song?mid=001qvvgF38HVc4`

| 参数类型 | 参数 | 是否必须 | 说明 | 默认值 |
| - | - | - | - | - |
| Headers | token | √ | 身份验证参数 | 参见 1.13 |
| Parameters | mid | √ | 音乐 mid | 无 |

### 1.2 获取音乐播放地址

接口地址： `http://api.kangaroohy.com/tencent/song/url`
请求示例： `http://api.kangaroohy.com/tencent/song/url?mid=001qvvgF38HVc4&quality=320`

| 参数类型 | 参数 | 是否必须 | 说明 | 默认值 |
| - | - | - | - | - |
| Headers | token | √ | 身份验证参数 | 参见 1.13 |
| Parameters | mid | √ | 音乐 mid | 无 |
| Parameters | quality | × | 音乐音质 | 128 |

> 说明： quality 类型：128 320 flac（~~目前只支持 m4a 和 128~~ 移除 m4a，其余都已支持。）

### 1.3 获取音乐歌词

接口地址： `http://api.kangaroohy.com/tencent/song/lrc`
请求示例： `http://api.kangaroohy.com/tencent/song/lrc?mid=001qvvgF38HVc4`

| 参数类型 | 参数 | 是否必须 | 说明 | 默认值 |
| - | - | - | - | - |
| Headers | token | √ | 身份验证参数 | 参见 1.13 |
| Parameters | mid | √ | 音乐 mid | 无 |

### 1.4 获取专辑详情

接口地址： `http://api.kangaroohy.com/tencent/album/url`
请求示例： `http://api.kangaroohy.com/tencent/album/url?id=7876962`

| 参数类型 | 参数 | 是否必须 | 说明 | 默认值 |
| - | - | - | - | - |
| Headers | token | √ | 身份验证参数 | 参见 1.13 |
| Parameters | id | √ | 专辑 ID | 无 |

### 1.5 搜索

接口地址： `http://api.kangaroohy.com/tencent/search`
请求示例： `http://api.kangaroohy.com/tencent/search?keyword=周杰伦&type=song&pageSize=20&page=1`

| 参数类型 | 参数 | 是否必须 | 说明 | 默认值 |
| - | - | - | - | - |
| Headers | token | √ | 身份验证参数 | 参见 1.13 |
| Parameters | keyword | √ | 搜索关键词 | 无 |
| Parameters | type | √ | 搜索类型 | 无 |
| Parameters | pageSize | × | 请求数量 | 20 |
| Parameters | page | × | 分页 | 1 |

> 说明：
>
> 1. 当前 keyword 支持搜索 `歌曲 专辑 歌单 mv`
> 2. 当前支持的 type 类型 `song album playlist mv`
> 3. 当 `type=song` 时，keyword 可以是歌手的名字

### 1.6 排行榜

接口地址： `http://api.kangaroohy.com/tencent/toplist`
请求示例： `http://api.kangaroohy.com/tencent/toplist?id=4`

| 参数类型 | 参数 | 是否必须 | 说明 | 默认值 |
| - | - | - | - | - |
| Headers | token | √ | 身份验证参数 | 参见 1.13 |
| Parameters | id | √ | 排行榜 ID | 无 |

### 1.7 歌单分类

接口地址： `http://api.kangaroohy.com/tencent/playlist/category`
请求示例： `http://api.kangaroohy.com/tencent/playlist/category`

| 参数类型 | 参数 | 是否必须 | 说明 | 默认值 |
| - | - | - | - | - |
| Headers | token | √ | 身份验证参数 | 参见 1.13 |

### 1.8 根据歌单分类 ID 获取歌单

接口地址： `http://api.kangaroohy.com/tencent/playlist`
请求示例： `http://api.kangaroohy.com/tencent/playlist?categoryId=10000000&pageSize=20&page=1`

| 参数类型 | 参数 | 是否必须 | 说明 | 默认值 |
| - | - | - | - | - |
| Headers | token | √ | 身份验证参数 | 参见 1.13 |
| Parameters | id | √ | 歌单分类 ID | 无 |
| Parameters | pageSize | × | 请求数量 | 20 |
| Parameters | page | × | 分页 | 1 |

### 1.9 获取歌单详情

接口地址： `http://api.kangaroohy.com/tencent/playlist/url`
请求示例： `http://api.kangaroohy.com/tencent/playlist/url?id=7128045988`

| 参数类型 | 参数 | 是否必须 | 说明 | 默认值 |
| - | - | - | - | - |
| Headers | token | √ | 身份验证参数 | 参见 1.13 |
| Parameters | id | √ | 歌单 ID | 无 |

### 1.10 获取 mv 分类

接口地址： `http://api.kangaroohy.com/tencent/mv/category`
请求示例： `http://api.kangaroohy.com/tencent/mv/category`

| 参数类型 | 参数 | 是否必须 | 说明 | 默认值 |
| - | - | - | - | - |
| Headers | token | √ | 身份验证参数 | 参见 1.13 |

### 1.11 根据 mv 分类 ID 获取 mv

接口地址： `http://api.kangaroohy.com/tencent/mv`
请求示例： `http://api.kangaroohy.com/tencent/mv?areaid=15&versionid=7&pageSize=20&page=1`

| 参数类型 | 参数 | 是否必须 | 说明 | 默认值 |
| - | - | - | - | - |
| Headers | token | √ | 身份验证参数 | 参见 1.13 |
| Parameters | areaid | √ | 区域 ID | 无 |
| Parameters | versionid | √ | 版本 ID | 无 |
| Parameters | pageSize | × | 请求数量 | 20 |
| Parameters | page | × | 分页 | 1 |

### 1.12 获取 mv 播放地址

接口地址： `http://api.kangaroohy.com/tencent/mv/url`
请求示例： `http://api.kangaroohy.com/tencent/mv/url?vid=t0032kwa29w`

| 参数类型 | 参数 | 是否必须 | 说明 | 默认值 |
| - | - | - | - | - |
| Headers | token | √ | 身份验证参数 | 参见 1.13 |
| Parameters | id | √ | mv ID | 无 |

### 1.13 获取 token 授权码

接口地址： `http://api.kangaroohy.com/usertoken`
请求示例： `http://api.kangaroohy.com/usertoken?username=***&telephone=*****`

| 参数 | 是否必须 | 说明 | 默认值 |
| - | - | - | - |
| username | √ | 姓名 | 无 |
| telephone | √ | 手机号 | 无 |

> 注：
>
> 1. 需要与本人联系，后台添加用户成功后，才能获得 token 授权码。
> 2. 姓名和手机号，仅作为 token 获取凭证，不会作为他用，如果介意，请左转。
> 3. 每次获取 token 后，原 token 将自动失效。

## 2 每日一句

### 2.1 ONE·一个

接口地址： `http://api.kangaroohy.com/one/json`
请求示例： `http://api.kangaroohy.com/one/json`

### 2.2 金山词霸

接口地址： `http://api.kangaroohy.com/iciba/json`
请求示例： `http://api.kangaroohy.com/iciba/json`
